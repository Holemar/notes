﻿
//头部菜单移动
var menu_move = {};
menu_move.away = 0; // 要移动到的位置
menu_move.timer = null; // 移动函数的记录
menu_move.objWidth = 80; // 每个菜单的宽度

// 触发移动
menu_move.menuInterval=function(){
    if (menu_move.timer) {
        clearInterval(menu_move.timer);
    }
    var odiv = document.getElementById("menu_bg");
    var oul = odiv.getElementsByTagName("ul")[0];
    var step = 0; // 每次的偏移量
    var left = 0; // 正在移动到的位置
    var timers = 10; // 停止移动的触发次数,为了节省CPU
    // 执行移动
    menu_move.timer = setInterval(function(){
        step += (menu_move.away - odiv.offsetLeft) / 10;
        step = step * 0.78;
        left = parseInt(odiv.offsetLeft + step);
        odiv.style.left = left + 'px';
        oul.style.left = -left + 'px';
        // 当位置已经移动到正确时,还要继续再移动几次,以保持左右摆的效果
        if(step<1 && Math.abs(menu_move.away - left)<5){
            // 左右摆到指定次数之后,停止移动,以节省cpu
            if(timers-- < 0){
                clearInterval(menu_move.timer);
                // 停止移动之后,精确移到指定位置
                odiv.style.left = menu_move.away + 'px';
                oul.style.left = -menu_move.away + 'px';
            }
        }
    }, 30);
};

// 获取元素位置
menu_move.getOffset = function(element) {
    var left = element.offsetLeft;
    while(element = element.offsetParent) {
        left += element.offsetLeft;
    }
    return left;
};

// 移动到指定位置
menu_move.moveTo = function(name){
    if (!name) return;
    menu_move.start();

    var pdiv = document.getElementById("menu_t");
    var odiv = document.getElementById("menu_bg");
    var oul = odiv.getElementsByTagName("ul")[0];
    var oli = pdiv.getElementsByTagName("ul")[0].getElementsByTagName("li");
    // 遍历每个 li 对象,比较它们的文字
    var i = 0;
    for (; i < oli.length; i++) {
        var li = oli[i];
        // 如果文字相同，则认为是这对象,将高亮移动到这对象上
        if(li.getElementsByTagName('span')[0].innerHTML == name){
            var away = 2 + menu_move.objWidth * li.index;
            odiv.style.left = away + 'px';
            oul.style.left = -away + 'px';
            break;
        }
    }

    // 离开此菜单的事件,还原到指定的位置上
    pdiv.onmouseout = function(event){
        //获取不同浏览器的 event
        event = event || window.event;
        // 将会去到的元素
        var target = event.relatedTarget || event.toElement || false;
        if (!target)return;
        while (target.parentNode && (target.tagName !== "DIV" || target.id !== 'menu_t')) {
            target = target.parentNode;
        }
        // 如果还在菜单里面
        if (target.parentNode && target.tagName === "DIV" && target.id === 'menu_t')return;

        menu_move.away = 2 + menu_move.objWidth * i;
        menu_move.menuInterval();
    };
};

// 页面加载后执行菜单移动
menu_move.start = function () {
    // 作一个标志，避免重复执行此函数
    if (menu_move.ready) return;
    menu_move.ready = true;
    var pdiv = document.getElementById("menu_t");
    // 这里是使用两层相同内容的菜单来显示的
    var odiv = document.getElementById("menu_bg");
    var oul = odiv.getElementsByTagName("ul")[0];
    // 复制内容
    var iul = document.createElement('UL');
    iul.innerHTML = oul.innerHTML;
    pdiv.insertBefore(iul, odiv);
    var oli = iul.getElementsByTagName("li");
    var minLeft = menu_move.getOffset(oli[0]);
    var maxLeft = menu_move.getOffset(oli[oli.length - 1]);
    var objWidth = menu_move.objWidth = (maxLeft - minLeft) / (oli.length - 1);
    // 遍历每个 li 对象,注册它们的鼠标移上事件
    for (var i = 0; i < oli.length; i++) {
        oli[i].index = i;
        oli[i].onmouseover = function () {
            menu_move.away = 2 + objWidth * this.index;
            menu_move.menuInterval();
        };
    }
};

// 添加到 onload 事件,页面加载后执行
// IE
if (window.attachEvent) {
    window.attachEvent('onload', menu_move.start);
}
// firfox
else if (window.addEventListener) {
    window.addEventListener('load', menu_move.start, false);
}


window.onerror = function(msg, url, sLine) {
    var errorMsg = "There was an error on this page.\n\n";
    errorMsg += "Error: " + msg + "\n";
    errorMsg += "URL: " + url + "\n";
    errorMsg += "Line: " + sLine + "\n\n";
    errorMsg += "Click OK to continue.\n\n";
    alert(errorMsg);
    // 返回true,会消去 IE下那个恼人的“网页上有错误”的提示
    return true;
};
