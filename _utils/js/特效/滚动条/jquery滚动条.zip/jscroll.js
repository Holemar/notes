/**
 *
 * Copyright (c) 2009 May(qq:104010230)
 * http://www.winwill.com
 * http://www.winwill.com/jquery/jscroll.html
 * admin@winwill.com
 */
jQuery.fn.extend({
    //添加滚轮事件//by jun
	mousewheel:function(Func){
		return this.each(function(){
			var _self = this;
		    _self.D = 0;//滚动方向
			if(jQuery.browser.msie||jQuery.browser.safari){
                // IE 滚轮事件直接用 element.onmousewheel 即可,坐标用 event.wheelDelta 获取
			   _self.onmousewheel=function(){_self.D = event.wheelDelta;event.returnValue = false;Func && Func.call(_self);};
			}else{
                // 火狐需要注册滚轮事件,坐标用 element..detail
			   _self.addEventListener("DOMMouseScroll",function(e){
					_self.D = e.detail>0?-1:1;
					e.preventDefault();
					Func && Func.call(_self);
			   },false);
			}
		});
	},
	jscroll:function(j){
        // 默认值
        var jun = {
            W: "15px", //设置滚动条宽度
            BgUrl: "", //设置滚动条背景图片地址
            Bg: "#efefef", //设置滚动条背景图片position,颜色等
            Bar: {
                Pos: "up", //设置滚动条初始化位置,up在顶部,bottom在底部
                Bd: { //设置滚动滚轴边框颜色：
                    Out: "#b5b5b5", // 鼠标离开
                    Hover: "#ccc" // 鼠标经过
                },
                Bg: { //设置滚动条滚轴背景：
                    Out: "#fff", // 鼠标离开
                    Hover: "#fff", // 鼠标经过
                    Focus: "orange" //焦点
                }
            },
            Btn: {
                btn: true, //是否显示上下按钮, false为不显示
                uBg: {//设置上按钮背景：鼠标离开(默认)，经过，点击
                    Out: "#ccc",
                    Hover: "#fff",
                    Focus: "orange"
                },
                dBg: {//设置下按钮背景：鼠标离开(默认)，经过，点击
                    Out: "#ccc",
                    Hover: "#fff",
                    Focus: "orange"
                }
            },
            Fn: function() {} //滚动时候触发的方法
        };
        // 设值
        j = jQuery.extend(true, jun, j);
        // 对每个jquery 元素设值
		return this.each(function(){
			var _self = this;
			var Stime,Sp=0,Isup=0;
			jQuery(_self).css({overflow:"hidden",position:"relative",padding:"0px"});
			var dw = jQuery(_self).width(), dh = jQuery(_self).height()-1;
			var sw = j.W ? parseInt(j.W) : 21;
			var sl = dw - sw;
			var bw = j.Btn.btn==true ? sw : 0;
			if(jQuery(_self).children(".jscroll-c").height()==null){//存在性检测
		    jQuery(_self).wrapInner("<div class='jscroll-c' style='top:0px;z-index:9999;zoom:1;position:relative'></div>");
			jQuery(_self).children(".jscroll-c").prepend("<div style='height:0px;overflow:hidden'></div>");
			jQuery(_self).append("<div class='jscroll-e' unselectable='on' style=' height:100%;top:0px;right:0;-moz-user-select:none;position:absolute;overflow:hidden;z-index:10000;'><div class='jscroll-u' style='position:absolute;top:0px;width:100%;left:0;background:blue;overflow:hidden'></div><div class='jscroll-h'  unselectable='on' style='background:green;position:absolute;left:0;-moz-user-select:none;border:1px solid'></div><div class='jscroll-d' style='position:absolute;bottom:0px;width:100%;left:0;background:blue;overflow:hidden'></div></div>");
			}
			var jscrollc = jQuery(_self).children(".jscroll-c");
			var jscrolle = jQuery(_self).children(".jscroll-e");
			var jscrollh = jscrolle.children(".jscroll-h");
			var jscrollu = jscrolle.children(".jscroll-u");
			var jscrolld = jscrolle.children(".jscroll-d");
			if(jQuery.browser.msie){document.execCommand("BackgroundImageCache", false, true);}
			jscrollc.css({"padding-right":sw});
			jscrolle.css({width:sw,background:j.Bg,"background-image":j.BgUrl});
			jscrollh.css({top:bw,background:j.Bar.Bg.Out,"background-image":j.BgUrl,"border-color":j.Bar.Bd.Out,width:sw-2});
			jscrollu.css({height:bw,background:j.Btn.uBg.Out,"background-image":j.BgUrl});
			jscrolld.css({height:bw,background:j.Btn.dBg.Out,"background-image":j.BgUrl});
			jscrollh.hover(function(){if(Isup==0)jQuery(this).css({background:j.Bar.Bg.Hover,"background-image":j.BgUrl,"border-color":j.Bar.Bd.Hover})},function(){if(Isup==0)jQuery(this).css({background:j.Bar.Bg.Out,"background-image":j.BgUrl,"border-color":j.Bar.Bd.Out})});
			jscrollu.hover(function(){if(Isup==0)jQuery(this).css({background:j.Btn.uBg.Hover,"background-image":j.BgUrl})},function(){if(Isup==0)jQuery(this).css({background:j.Btn.uBg.Out,"background-image":j.BgUrl})});
			jscrolld.hover(function(){if(Isup==0)jQuery(this).css({background:j.Btn.dBg.Hover,"background-image":j.BgUrl})},function(){if(Isup==0)jQuery(this).css({background:j.Btn.dBg.Out,"background-image":j.BgUrl})});
			var sch = jscrollc.height();
			//var sh = Math.pow(dh,2) / sch ;//Math.pow(x,y)x的y次方
			var sh = (dh-2*bw)*dh / sch;
			if(sh<10){sh=10}
			var wh = sh/6; //滚动时候跳动幅度
		//	sh = parseInt(sh);
			var curT = 0,allowS=false;
			jscrollh.height(sh);
			if(sch<=dh){jscrollc.css({padding:0});jscrolle.css({display:"none"})}else{allowS=true;}
			if(j.Bar.Pos!="up"){curT=dh-sh-bw;setT();}
			jscrollh.bind("mousedown",function(e){
				j['Fn'] && j['Fn'].call(_self);
				Isup=1;
				jscrollh.css({background:j.Bar.Bg.Focus,"background-image":j.BgUrl});
				var pageY = e.pageY ,t = parseInt(jQuery(this).css("top"));
				jQuery(document).mousemove(function(e2){
					 curT =t+ e2.pageY - pageY;//pageY浏览器可视区域鼠标位置，screenY屏幕可视区域鼠标位置
						setT();
				});
				jQuery(document).mouseup(function(){
					Isup=0;
					jscrollh.css({background:j.Bar.Bg.Out,"background-image":j.BgUrl,"border-color":j.Bar.Bd.Out});
					jQuery(document).unbind();
				});
				return false;
			});
			jscrollu.bind("mousedown",function(e){
			j['Fn'] && j['Fn'].call(_self);
				Isup=1;
				jscrollu.css({background:j.Btn.uBg.Focus,"background-image":j.BgUrl});
				_self.timeSetT("u");
				jQuery(document).mouseup(function(){
					Isup=0;
					jscrollu.css({background:j.Btn.uBg.Out,"background-image":j.BgUrl});
					jQuery(document).unbind();
					clearTimeout(Stime);
					Sp=0;
				});
				return false;
			});
			jscrolld.bind("mousedown",function(e){
			j['Fn'] && j['Fn'].call(_self);
				Isup=1;
				jscrolld.css({background:j.Btn.dBg.Focus,"background-image":j.BgUrl});
				_self.timeSetT("d");
				jQuery(document).mouseup(function(){
					Isup=0;
					jscrolld.css({background:j.Btn.dBg.Out,"background-image":j.BgUrl});
					jQuery(document).unbind();
					clearTimeout(Stime);
					Sp=0;
				});
				return false;
			});
			_self.timeSetT = function(d){
				var self=this;
				if(d=="u"){curT-=wh;}else{curT+=wh;}
				setT();
				Sp+=2;
				var t =500 - Sp*50;
				if(t<=0){t=0};
				Stime = setTimeout(function(){self.timeSetT(d);},t);
			}
			jscrolle.bind("mousedown",function(e){
                j['Fn'] && j['Fn'].call(_self);
                curT = curT + e.pageY - jscrollh.offset().top - sh/2;
                asetT();
                return false;
			});
			function asetT(){
                if(curT<bw){curT=bw;}
                if(curT>dh-sh-bw){curT=dh-sh-bw;}
                jscrollh.stop().animate({top:curT},100);
                var scT = -((curT-bw)*sch/(dh-2*bw));
                jscrollc.stop().animate({top:scT},1000);
			};
			function setT(){
                if(curT<bw){curT=bw;}
                if(curT>dh-sh-bw){curT=dh-sh-bw;}
                jscrollh.css({top:curT});
                var scT = -((curT-bw)*sch/(dh-2*bw));
                jscrollc.css({top:scT});
			};
			jQuery(_self).mousewheel(function(){
                if(allowS!=true) return;
                j['Fn'] && j['Fn'].call(_self);
                if(this.D>0){curT-=wh;}else{curT+=wh;};
                setT();
			});
		});
	}
});
