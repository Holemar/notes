﻿/*javascript for Bubble Tooltips by Alessandro Fulciniti
- http://pro.html.it - http://web-graphics.com */

/**
 * 渲染A标签的鼠标事件
 * @param {String} id 是所有A标签所在DOM元素的id,没有参数则渲染整个页面所有的A标签
 */
function Tooltips(id){
    var links,i,h;
    if(!document.getElementById || !document.getElementsByTagName) return;
    Tooltips.AddCss(); // 用程序加载css,注意路径
    h=document.createElement("span");
    h.id="btc";
    h.setAttribute("id","btc");
    h.style.position="absolute";
    document.getElementsByTagName("body")[0].appendChild(h);
    // 选取A标签
    if(id==null) links=document.getElementsByTagName("a");
    else links=document.getElementById(id).getElementsByTagName("a");
    // 逐个地处理A标签
    for(i=0;i<links.length;i++){
        Tooltips.Prepare(links[i]);
    }
}

// 处理单个A标签
Tooltips.Prepare = function (el){
    var tooltip,t,b,s,l;
    // 截获A标签的title
    t=el.getAttribute("title");
    if(t==null || t.length==0) t="link:";
    el.removeAttribute("title");
    tooltip = Tooltips.CreateEl("span","tooltip");
    s = Tooltips.CreateEl("span","top");
    s.appendChild(document.createTextNode(t));
    tooltip.appendChild(s);
    // 获取A标签的href
    b = Tooltips.CreateEl("b","bottom");
    l = el.getAttribute("href");
    if(l.length>30) l=l.substr(0,27)+"...";
    b.appendChild(document.createTextNode(l));
    tooltip.appendChild(b);
    Tooltips.setOpacity(tooltip);
    // 鼠标移上事件
    el.onmouseover = function(e){
        document.getElementById("btc").appendChild(tooltip);
        Tooltips.Locate(e);
    };
    // 鼠标离开事件
    el.onmouseout = function(e){
        var d = document.getElementById("btc");
        if(d.childNodes.length>0) d.removeChild(d.firstChild);
    };
    // 鼠标移动事件
    el.onmousemove = Tooltips.Locate;
};

// 添加 css 文件
Tooltips.AddCss = function (){
    var l = Tooltips.CreateEl("link");
    l.setAttribute("type","text/css");
    l.setAttribute("rel","stylesheet");
    l.setAttribute("href","bt.css");
    l.setAttribute("media","screen");
    document.getElementsByTagName("head")[0].appendChild(l);
};

Tooltips.setOpacity = function(el){
    el.style.filter="alpha(opacity:95)";
    el.style.KHTMLOpacity="0.95";
    el.style.MozOpacity="0.95";
    el.style.opacity="0.95";
};

// 创建元素
Tooltips.CreateEl = function (t,c){
    var x=document.createElement(t);
    x.className=c;
    x.style.display="block";
    return(x);
};

// 获取鼠标的坐标
Tooltips.getMousePos = function(e) {
    e = e || window.event;
    var getX = 0, getY = 0;
    // firfox
    if (typeof e.pageX == 'number') {
        getX = 'e.pageX';
        getY = 'e.pageY';
    }
    // IE
    else if (typeof e.clientX == 'number') {
        if (document.documentElement && typeof document.documentElement.scrollLeft == 'number') {
            getX = 'e.clientX + document.documentElement.scrollLeft - document.documentElement.clientLeft';
            getY = 'e.clientY + document.documentElement.scrollTop - document.documentElement.clientTop';
        }
        else if (document.body && typeof document.body.scrollLeft == 'number') {
            getX = 'e.clientX + document.body.scrollLeft - document.body.clientLeft';
            getY = 'e.clientY + document.body.scrollTop - document.body.clientTop';
        }
    }
    // 重置函数,以提高效率,不用每次都判断
    eval('Tooltips.getMousePos = function(e) { e = e || window.event; return { x: ' + getX + ', y: ' + getY + ' }};');
    return Tooltips.getMousePos(e);
};

// 让气泡跟着鼠标移动
Tooltips.Locate = function (e){
    var pos = Tooltips.getMousePos(e);
    var e = document.getElementById("btc");
    e.style.top=(pos.y+10)+"px";
    e.style.left=(pos.x-20)+"px";
};