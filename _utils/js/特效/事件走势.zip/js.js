﻿
var co$ = function () {
    this.$ = function (v) {
        return document.getElementById(v)
    };
    this.$$ = function (o, e) {
        return this.$(o).getElementsByTagName(e)
    };
    this.isFunction = function (obj) {
        return toString.call(obj) === "[object Function]"
    };
    this.isArray = function (obj) {
        return toString.call(obj) === "[object Array]"
    };
    this.addEventHandler = function (a, b, c) {
        if (a.addEventListener) {
            a.addEventListener(b, c, false)
        } else {
            if (a.attachEvent) {
                a.attachEvent("on" + b, c)
            } else {
                a["on" + b] = c
            }
        }
    };
    this.removeEventHandler = function (a, b, c) {
        if (a.removeEventListener) {
            a.removeEventListener(b, c, false)
        } else {
            if (a.detachEvent) {
                a.detachEvent("on" + b, c)
            } else {
                a["on" + b] = null
            }
        }
    };
    this.getStyle = function (el, style) {
        if (!+"\v1") {
            style = style.replace(/\-(\w)/g, function (all, letter) {
                return letter.toUpperCase()
            });
            var value = el.currentStyle[style];
            (value == "auto") && (value = "0px");
            return value
        } else {
            return document.defaultView.getComputedStyle(el, null).getPropertyValue(style)
        }
    };
    this.$A = function (c) {
        if (!c) {
            return []
        }
        if ("toArray" in Object(c)) {
            return c.toArray()
        }
        var b = c.length || 0,
            a = new Array(b);
        while (b--) {
                a[b] = c[b]
            }
        return a
    };
    this.$R = function (s, e) {
        var arr = [];
        for (var i = s; i < e + 1; i++) {
            arr.push(i)
        }
        return arr
    };
    this.each = function (object, callback, args) {
        var name, i = 0,
            length = object.length,
            isObj = length === undefined;
        if (args) {
            if (isObj) {
                for (name in object) {
                    if (callback.apply(object[name], args) === false) {
                        break
                    }
                }
            } else {
                for (; i < length;) {
                    if (callback.apply(object[i++], args) === false) {
                        break
                    }
                }
            }
        } else {
            if (isObj) {
                for (name in object) {
                    if (callback.call(object[name], name, object[name]) === false) {
                        break
                    }
                }
            } else {
                for (var value = object[0]; i < length && callback.call(value, i, value) !== false; value = object[++i]) {}
            }
        }
        return object;
    }
};

var Ajax = function (url, callback) {
    var xmlHttp;

    // createXMLHttpRequest
    if (window.ActiveXObject) {
        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    } else if (window.XMLHttpRequest) {
        xmlHttp = new XMLHttpRequest();
    }

    // 发送 ajax Request
    try {
        xmlHttp.onreadystatechange = function () {
            if (xmlHttp.readyState == 4) {
                if (xmlHttp.status == 200 || xmlHttp.status == 0) {
                    var result = xmlHttp.responseText;
                    window.setTimeout(callback(result), 50);
                }
            }
        };
        xmlHttp.open("GET", url, true);
        xmlHttp.setRequestHeader("If-Modified-Since", "0");
        xmlHttp.setRequestHeader("Cache-Control", "no-cache");
        xmlHttp.setRequestHeader("Charset", "UTF-8");
        xmlHttp.send(null);
    } catch (exception) {
        alert("无法连接服务器!请稍后再试!");
    }
};

/* 位移动画 */
var move = function (element, position, speed, callback) { //移动到指定位置
    if (typeof(element) == 'string') element = document.getElementById(element); //判断是否是字符串
    if (!element.effect) {
        element.effect = {};
        element.effect.move = 0;
    }
    clearInterval(element.effect.move);
    var speed = speed || 10;
    var start = (function (elem) {
        var posi = {
            left: elem.offsetLeft,
            top: elem.offsetTop
        };
        while (elem = elem.offsetParent) {
            posi.left += elem.offsetLeft;
            posi.top += elem.offsetTop;
        };
        return posi;
    })(element);
    element.style.position = 'absolute';
    var style = element.style;
    var styleArr = [];
    if (typeof(position.left) == 'number') styleArr.push('left');
    if (typeof(position.top) == 'number') styleArr.push('top');
    element.effect.move = setInterval(function () {
        for (var i = 0; i < styleArr.length; i++) {
            start[styleArr[i]] += (position[styleArr[i]] - start[styleArr[i]]) * speed / 100;
            style[styleArr[i]] = start[styleArr[i]] + 'px';
        }
        for (var i = 0; i < styleArr.length; i++) {
            if (Math.round(start[styleArr[i]]) == position[styleArr[i]]) {
                if (i != styleArr.length - 1) continue;
            } else {
                break;
            }
            for (var i = 0; i < styleArr.length; i++) style[styleArr[i]] = position[styleArr[i]] + 'px';
            clearInterval(element.effect.move);
            if (callback) callback.call(element);
        }
    }, 20);
};


var Timer = function (hdId, bdId, indexId, Urls) {
    var _this = this,
        tmpA = "",
        arrTemp = 0,
        arrTempBefore = 0,
        argv = [],
        isChaochu = false;
    this.tempArray = new Array();
    this.Json2Array = function () {
            if (arguments[0].length <= 0) {
                _this.$(hdId).parentNode.style.display = "none";
                return false;
            }
            var json = eval("(" + arguments[0] + ")");
            //var articleArraySrc = json.Children[0].Children[3].Children;
            var articleArraySrc = json.Children;
            var articleArrayObj = new Array();
            var tempDate = "";
            var tempArray = new Array();
            try {
                for (var i = 0; i < articleArraySrc.length; i++) {
                    //var title = articleArraySrc[i].Children[1].Children[0] ? articleArraySrc[i].Children[1].Children[0].Content : "";
                    var title = articleArraySrc[i].Title || '';
                    //var Url = articleArraySrc[i].Children[4].Children[0] ? articleArraySrc[i].Children[4].Children[0].Content : "";
                    var Url = articleArraySrc[i].Url || '';
                    //var img = articleArraySrc[i].Children[5].Children[0] ? articleArraySrc[i].Children[5].Children[0].Content : "";
                    var img = articleArraySrc[i].ImgUrl || '';
                    //var time = articleArraySrc[i].Children[7].Children[0] ? articleArraySrc[i].Children[7].Children[0].Content : "";
                    var time = articleArraySrc[i].Time || '';
                    //var icocode = articleArraySrc[i].Children[9].Children[0] ? articleArraySrc[i].Children[9].Children[0].Content : "0";
                    var ico = articleArraySrc[i].Ico || '';

                    if (time == "") continue;
                    if (tempDate == "" || time.substr(0, 10) == tempDate.substr(0, 10)) {
                        tempArray.push({
                            "title": title,
                            "img": img,
                            "ico": ico,
                            "Url": Url
                        });
                        tempDate = time;
                    }
                    else {
                        articleArrayObj.push({
                            "time": tempDate,
                            "item": []
                        });
                        for (var j = 0; j < tempArray.length; j++) {
                            articleArrayObj[articleArrayObj.length - 1].item.push(tempArray[j]);
                        }
                        tempArray.splice(0, tempArray.length);
                        tempArray.push({
                            "title": title,
                            "img": img,
                            "ico": ico,
                            "Url": Url
                        });
                        tempDate = time;
                    }
                    if (i == articleArraySrc.length - 1 && tempArray.length > 0) articleArrayObj.push({
                        "time": tempDate,
                        "item": tempArray
                    });
                }
                _this.initTemp(eval(articleArrayObj));
                _this.move();
                return articleArrayObj;
            }
            catch (e) {
                alert(e);
            }
        };
    this.TimebarW = function () {
            return _this.$(hdId).offsetWidth;
        };
    this.TimeBarT = function () {
            return _this.TimebarW() / Math.round(Math.round(Math.round(Math.round((_this.tempArray[_this.tempArray.length - 1].time - this.tempArray[0].time) / 1000) / 60) / 60) / 24);
        };
    this.TimeBarC = function (a, b) {
            if (Math.round(Math.round(Math.round(Math.round((_this.tempArray[_this.tempArray.length - 1].time - this.tempArray[0].time) / 1000) / 60) / 60) / 24) > Math.round(_this.TimebarW() / 17)) {
                argv[hdId] = true;
                return Math.round(_this.TimebarW() / _this.tempArray.length);
            }
            var daysTimer = (_this.tempArray[b].time - this.tempArray[a].time) / 1000 / 60 / 60 / 24;
            if (parseInt(daysTimer * _this.TimeBarT(), 10) < 17) {
                return parseInt(daysTimer * _this.TimeBarT() + (17 - parseInt(daysTimer * _this.TimeBarT(), 10)), 10);
            } else {
                return parseInt(daysTimer * _this.TimeBarT(), 10);
            }
        };
    this.pushTemp = function (a) {
            for (var i = 0; i < a.length; i++) {
                _this.tempArray.push({
                    time: Date.parse(new Date(a[i].time.replace(/-/g, "/"))),
                    item: a[i].item
                })
            };
            _this.tempArray.sort(function (a, b) {
                return a["time"] > b["time"] ? 1 : -1
            }); //排列日期顺序
        };
    this.creatPoptime = function (str) {
            var T = new Date(str);
            return T.getFullYear() + "." + (T.getMonth() + 1) + "." + T.getDate();
        };
    this.creatTips = function (n) {
            var tmp = '';
            if (_this.tempArray[n].item.length < 1) return;
            if (_this.tempArray[n].item.length == 1) {
                tmp += '<div class="item" id="' + indexId + '_Time-cot-' + n + '"><table style="margin:0;"><tr><td style="border-right:0px;margin-right:0px;">';
                if (_this.tempArray[n].item[0].img !== "") {
                    tmp += '<a href="' + _this.tempArray[n].item[0].Url + '#pref=timeline" target="_blank"><img src="' + _this.tempArray[n].item[0].img + '"  onload="javascript:if(this.width>75)this.width=75;" height="50"/></a>';
                }
                tmp += '<a href="' + _this.tempArray[n].item[0].Url + '#pref=timeline" target="_blank" class="link">' + _this.tempArray[n].item[0].title + '</a></td></tr></table></div>';
            } else {
                tmp += '<div class="item" id="' + indexId + '_Time-cot-' + n + '"><table style="margin:0;"><tr>';
                if (_this.tempArray[n].item.length < 3) {
                    for (var i = _this.tempArray[n].item.length - 1; i >= 0; i--) {
                        if (i == 0) {
                            tmp += '<td>';
                        } else {
                            if (i == 2 && _this.tempArray[n].item.length <= 2 || i == 1 && _this.tempArray[n].item.length > 2) {
                                tmp += '<td style="border-right:0px;">';
                            } else {
                                tmp += '<td>';
                            }
                        }
                        var title = _this.tempArray[n].item[i].title;
                        if (title.length > 21) {
                            title = title.substring(0, 19);
                        }
                        if (_this.tempArray[n].item[i].img) {
                            tmp += '<a href="' + _this.tempArray[n].item[i].Url + '#pref=timeline" target="_blank"><img onload="javascript:if(this.width>75)this.width=75;" height="50"  src="' + _this.tempArray[n].item[i].img + '"/></a>';
                        }
                        if (_this.tempArray[n].item[i].ico) {
                            tmp += '<a href="' + _this.tempArray[n].item[i].Url + '#pref=timeline" target="_blank" class="link"><img src="' + _this.tempArray[n].item[i].ico + '" style="margin-left:8px;"/>' + title + '</a>';
                        } else {
                            tmp += '<a href="' + _this.tempArray[n].item[i].Url + '#pref=timeline" target="_blank" class="link">' + title + '</a>';
                        }
                        tmp += '</td>';
                    }
                } else { //3个节点
                    for (var i = _this.tempArray[n].item.length - 1; i >= 0; i--) {
                        var title = _this.tempArray[n].item[i].title;
                        if (title.length > 20) {
                            title = title.substring(0, 20);
                        }
                        if (i == 0) {
                            tmp += '<td>';
                        } else {
                            if (i == 1 && _this.tempArray[n].item.length <= 2 || i == 0 && _this.tempArray[n].item.length > 2) {
                                tmp += '<td style="border-right:0px;">';
                            } else {
                                tmp += '<td>';
                            }
                        }
                        if (_this.tempArray[n].item[i].ico) {
                            tmp += '<a href="' + _this.tempArray[n].item[i].Url + '#pref=timeline" target="_blank" class="link"><img src="' + _this.tempArray[n].item[i].ico + '" style="margin-left:8px;"/>' + title + '</a>';
                        } else {
                            tmp += '<a href="' + _this.tempArray[n].item[i].Url + '#pref=timeline" target="_blank" class="link">' + title + '</a>';
                        }

                        tmp += '</td>';
                    }
                }
                tmp += '</tr></table></div>';
            };
            _this.$(bdId).innerHTML += tmp;
            return false;

        };
    this.initTemp = function (a) {
            this.pushTemp(a);
            for (var i = 0; i < _this.tempArray.length; i++) {
                if (i == 0) {
                    tmpA += "<li style='left:0px'><div class='popTime' id='" + indexId + "_n_0' style='display:none'><span class='t_head'>" + _this.creatPoptime(_this.tempArray[0].time) + "</span><span class='t_arr'></span></div></li>";
                    _this.$(bdId).innerHTML += '<span class="arr" id="' + indexId + '_arr" style="left:3px;"></span>';
                    _this.creatTips(i);
                    if (_this.tempArray.length == 1) {
                        _this.$(hdId).innerHTML = "<ul>" + tmpA + "</ul>";
                        _this.$('' + indexId + '_Time-cot-0').style.display = "block";
                        _this.$('' + indexId + '_n_0').style.display = "block";
                        _this.$$(hdId, "li")[0].className = "hover";
                        return false;
                    }
                }
                if (i == _this.tempArray.length - 1) {
                    return false;
                }
                _this.creatTips(i + 1);
                arrTemp += parseInt(_this.TimeBarC(i, i + 1), 10);
                tmpA += "<li  id='" + indexId + "_p_" + (i + 1) + "' rel='+" + arrTemp + "'><div class='popTime' id='" + indexId + "_n_" + (i + 1) + "' style='display:none'><span class='t_head'>" + _this.creatPoptime(_this.tempArray[i + 1].time) + "</span><span class='t_arr'></span></div><div class='cot'></div></li>";
                _this.$(hdId).innerHTML = "<ul>" + tmpA + "</ul>";
                _this.$('' + indexId + '_Time-cot-0').style.display = "block";
                _this.$('' + indexId + '_n_0').style.display = "block";
                _this.$$(hdId, "li")[0].className = "hover";
                _this.$('' + indexId + '_n_' + (_this.$$(hdId, "li").length - 1) + '').className = "popTime_last";
                _this.$('' + indexId + '_n_' + (_this.$$(hdId, "li").length - 1) + '').style.display = "block";
            };
        };
    this.move = function () {
            var lis = _this.$$(hdId, "li"),
                leftV = [],
                indexT = lis.length;
            if (parseInt(lis[lis.length - 1].getAttribute("rel"), 10) >= _this.TimebarW()) {
                    isChaochu = true;
                }
            for (var i = 0; i < indexT; i++) {
                    if (i !== 0) {
                        if (isChaochu) {
                            leftV[i] = parseInt(lis[i].getAttribute("rel") - (parseInt(lis[lis.length - 1].getAttribute("rel"), 10) - _this.TimebarW()), 10);
                        } else {
                            leftV[i] = parseInt(lis[i].getAttribute("rel"), 10);
                        }
                        if (leftV[i] < 17) {
                            leftV[i] = 17;
                        }
                        if (i == lis.length - 1) {
                            move(_this.$("" + indexId + "_p_" + i), {
                                left: _this.TimebarW() - 17
                            });
                        } else {
                            move(_this.$("" + indexId + "_p_" + i), {
                                left: leftV[i]
                            });
                        }
                    };
                    (function (f) {
                        _this.addEventHandler(lis[f], "mouseover", function () {
                            leftV[f] = parseInt(_this.getStyle(lis[f], 'left'), 10) || 2;
                            lis[f].style.zIndex = "99";
                            for (var k = 0; k < lis.length; k++) {
                                if (f == k) {
                                    _this.$('' + indexId + '_Time-cot-' + f).style.display = "block";
                                    _this.$('' + indexId + '_n_' + f).style.display = "block";
                                    _this.$("" + indexId + "_arr").style.left = leftV[f] + "px";
                                    if (parseInt(_this.$('' + indexId + '_Time-cot-' + f).clientWidth + leftV[f]) > _this.TimebarW() && leftV[f] > _this.TimebarW() / 2) {
                                        if ((leftV[f] - _this.$('' + indexId + '_Time-cot-' + f).offsetWidth + 17) < 0) {
                                            _this.$('' + indexId + '_Time-cot-' + f).style.left = 0 + "px";
                                        } else {
                                            _this.$('' + indexId + '_Time-cot-' + f).style.left = (leftV[f] - _this.$('' + indexId + '_Time-cot-' + f).offsetWidth + 17) + "px";
                                        }
                                    } else if (leftV[f] < _this.TimebarW() / 2 && parseInt(_this.$('' + indexId + '_Time-cot-' + f).offsetWidth) > _this.TimebarW() / 2) {
                                        _this.$('' + indexId + '_Time-cot-' + f).style.left = 0 + "px";
                                    } else {
                                        _this.$('' + indexId + '_Time-cot-' + f).style.left = leftV[f] - 12 + "px";
                                    }
                                    _this.$('' + indexId + '_n_' + (_this.$$(hdId, "li").length - 1) + '').className = "popTime";
                                    lis[f].className = "hover";
                                } else {
                                    _this.$('' + indexId + '_n_' + k).style.display = "none";
                                    _this.$('' + indexId + '_Time-cot-' + k).style.display = "none";
                                    lis[k].className = "";
                                }
                            }

                        });
                    })(i);
                }
        };
    new Ajax(Urls, this.Json2Array);
};


Timer.prototype = new co$();
//Ajax.prototype = new co$();


