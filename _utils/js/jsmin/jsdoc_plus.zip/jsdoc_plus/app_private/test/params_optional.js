
/**
 * @param {Page[]} pages
 * @param {number} [id] Specifies the id, if applicable.
 * @param {String} [title = This is untitled.] Specifies the title.
 */
function Document(pages, id, title){
}