definePackage("com.test.geometry");

var geometry=com.test.geometry;

/**
 *@class Point���̳��Գ�����Geometry
 *@extends geometry.Geometry
 *@param x - {int}  x����
 *@param y - {int}  y����
 */
geometry.Point = function (x, y) {
	//geometry.Geometry.call(this);
	//this.x = x;
	//this.y = y;
	
		
	/**
	 *�õ�Point��Xֵ(x����)
	 *@return int
	 */
	this.getX=function(){return this.x;};
	
	
	/**
	 *�õ�Point��Yֵ(y����)
	 *@return int
	 */
	this.getY=function(){};
	
	
	//===========����Ϊ���Ǹ���Geometry�ķ���===============
	/**
	 *Returns the name of the instantiable subtype of Geometry of which this geometric object is an instantiable member. 
	 *The name of the subtype of Geometry is returned as a string. 
	 *@return String
	 */
	this.getGeometryType=function(){return "Point";};
	
	
	/**
	 *The minimum bounding box for  this Geometry, returned as a Geometry. The 
	 *polygon is defined by the corner points of the bounding box [(MINX, MINY), (MAXX, MINY), (MAXX, MAXY), 
	 *(MINX, MAXY), (MINX, MINY)]. Minimums for Z and M may be added. The simplest representation of an 
	 *Envelope is as two direct positions, one containing all the minimums, and another all the maximums. In some 
	 *cases, this coordinate will be outside the range of validity for the Spatial Reference System. 
	 *@return Geometry
	 */
	this.envelope=function(){};
	
	
	/**
	 *Exports this geometric object to a specific Well-known Text Representation of Geometry.
	 *@return String
	 */
	this.asText=function(){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object is the empty Geometry. If true, then this 
	 *geometric object represents the empty point set "empty set" for the coordinate space. The return type is integer, but is 
	 *interpreted as Boolean, TRUE=1, FALSE=0.  
	 *@return Boolean
	 */
	this.isEmpty=function(){};
	
	
	/**
	 *Returns 1 (TRUE) if this geometric object has no anomalous geometric points, such 
	 *as self intersection or self tangency. The description of each instantiable geometric class will include the 
	 *specific conditions that cause an instance of that class to be classified  as not simple. The return type is 
	 *integer, but is interpreted as Boolean, TRUE=1, FALSE=0. 
	 *@return Boolean
	 */
	this.isSimple=function(){};
	
	
	/**
	 *Returns the closure of the combinatorial boundary of  this geometric object 
	 *(Reference [1], section 3.12.2). Because the result of  this function is a closure, and hence topologically 
	 *closed, the resulting boundary can be represented using representational Geometry primitives (Reference [1], 
	 *section 3.12.2). The return type is integer, but is interpreted as Boolean, TRUE=1, FALSE=0. 
	 *@return Geometry
	 */
	this.Boundary=function(){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object is ��spatially equal�� to anotherGeometry. 
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.equals=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object is ��spatially disjoint�� from anotherGeometry. 
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.disjoint=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object ��spatially intersects�� anotherGeometry. 
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean 
	 */
	this.intersects=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object ��spatially touches�� anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.touches=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object ��spatially crosses�� anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.crosses=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if this geometric object is ��spatially within�� anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.within=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object ��spatially contains�� anotherGeometry. 
	 *@param anotherGeometry - {Geometry}
	 *@return Boolean
	 */
	this.contains=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this geometric object ��spatially overlaps�� anotherGeometry.
	 *@param anotherGeometry - {Geometry} 
	 *@return Boolean
	 */
	this.overlaps=function(anotherGeometry){};
	
	
	/**
	 *Returns 1 (TRUE) if  this 
	 *geometric object is spatially related to anotherGeometry by testing for intersections between the interior, 
	 *boundary and exterior of the two geometric objects as specified by the values in the intersectionPatternMatrix. 
	 *This returns FALSE if all the tested intersections are empty except exterior (this) intersect exterior (another). 
	 *@param anotherGeometry - {Geometry} 
	 *@param matrix - {String} 
	 *@return Boolean
	 */
	this.relate=function(anotherGeometry,matrix){};
	
	
	/**
	 *Returns the shortest distance between any two Points in 
	 *the two geometric objects as calculated in the spatial reference system of this geometric object. Because the 
	 *geometries are closed, it is possible to find a point on each geometric object involved, such that the distance 
	 *between these 2 points is the returned distance between their geometric objects. 
	 *@param anotherGeometry - {Geometry}
	 *@return Double
	 */
	this.distance=function(anotherGeometry){};
	
	
	/**
	 *Returns a geometric object that represents all Points whose distance 
	 *from this geometric object is less than or equal to distance. Calculations are in the spatial reference system of 
	 *this geometric object. Because of the limitations of linear  interpolation, there will often be some relatively 
	 *small error in this distance, but it should be near the resolution of the coordinates used.
	 *@param distance - {Double}
	 *@return Geometry
	 */
	this.buffer=function(distance){};
	
	
	/**
	 *Returns a geometric object that represents the 
	 *Point set intersection of this geometric object with anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Geometry
	 */
	this.intersection=function(anotherGeometry){};
	
	
	/**
	 *Returns a geometric object that represents the Point set 
	 *union of this geometric object with anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Geometry
	 */
	this.union=function(anotherGeometry){};
	
	
	/**
	 *Returns a geometric object that represents the Point 
	 *set difference of this geometric object with anotherGeometry.
	 *@param anotherGeometry - {Geometry}
	 *@return Geometry
	 */
	this.difference=function(anotherGeometry){};
	
	
	/**
	 *Returns a geometric object that represents the 
	 *Point set symmetric difference of this geometric object with anotherGeometry. 
	 *@param anotherGeometry - {Geometry}
	 *@return Geometry
	 */
	this.symDifference=function(anotherGeometry){};
};

geometry.Point.prototype = geometry.Geometry;
